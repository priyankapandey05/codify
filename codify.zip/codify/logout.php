<?php 
    session_start();
    $con=mysqli_connect("localhost","root","","codify")or die(mysqli_error($con));
        session_destroy();
        header('location:main.php');
?>