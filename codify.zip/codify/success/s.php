<?php
	$con=mysqli_connect("localhost","root","","codify")or die(mysqli_error($con));
		 $pass_query="SELECT FLOOR(RAND()*10000)+10 password";
		$pass=mysqli_query($con,$pass_query)or die (mysql_error($con));
		$password=mysqli_fetch_assoc($pass)['password'];
		$fullname= (isset($_POST['fullname']) ? $_POST['fullname'] : '');
	 	$college= (isset($_POST['college']) ? $_POST['college'] : '');
	  	$branch = (isset($_POST['branch']) ? $_POST['branch'] : '');
	 	$email= (isset($_POST['email']) ? $_POST['email'] : '');
	 	$phone= (isset($_POST['phone']) ? $_POST['phone'] : '');
	  	$event= (isset($_POST['event']) ? $_POST['event'] : '');
		$eve1="";
		$event = is_array($event) ? $event : array($event);
		foreach ($event as $eve) {
			$eve1 .= $eve.",";  
		}
	 	$team= (isset($_POST['team']) ? $_POST['team'] : '');
		$check_query="SELECT count(*) as count FROM register WHERE email='$email'";	
		$check=mysqli_query($con,$check_query)or die (mysql_error($con));
		$check1=mysqli_fetch_assoc($check)['count'];
		if($check1>0){
//			echo"The user is already registered.Please try with another email ID.";
//			header( "refresh:0; url=../register/reg2.php" );
			echo "<script>if(confirm('The user is already registered.Please try with another email ID.')){document.location.href='../register/reg2.php'};</script>";

		}
		else{
		$query="INSERT INTO codify.register (fullname,college,branch,email,phone,event,team,password) VALUES ('$fullname','$college','$branch','$email','$phone','$eve1','$team','$password')";
		$query_result=mysqli_query($con,$query)or die(mysqli_error($con));
}?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Success</title>
  <!--Favicon-->

  <link rel="Favicon" href="https://icons8.com/icon/59997/shopping-cart">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

  <!--CSS Style Sheets-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="s.css">

  <!--Font Awesome-->

  <script src="https://kit.fontawesome.com/0873bde953.js" crossorigin="anonymous"></script>
  <script src="js/jquery.js"></script>
  <script src="js/script.js"></script>

  <!--Google Fonts-->


  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@800&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cabin:ital,wght@1,600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital@1&display=swap" rel="stylesheet">


  <!--Bootstrap Scripts-->

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
    crossorigin="anonymous"></script>



</head>

<body>


  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <a class="navbar-brand" href="../main.php"><i class="fab fa-codiepie"></i> C&lt;&gt;diFY</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse navbar-light" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="../main.html"><b>Home</b></a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid2">
    <img src="tick.png" width="450" height="350" class="under">
    <h2 style="padding-bottom: 3%;">Successfully Registered</h2>

	  <h4 style="color:red; text-align:center;">This id password will be used in future. So take a screenshot of it and please don't share this with anyone!!</h4>
    <table>
      <tr>	
        <td>REGISTRATION ID</td>
        <td><?php 
	        $query="SELECT id FROM codify.register WHERE email='$email'";
	        $get_id_res=mysqli_query($con,$query)or die(mysqli_error($con));
	         $id = mysqli_fetch_assoc($get_id_res)['id'];
	        echo $id;
	        ?>
	</td>
      </tr>
	    <tr>
        		<td>Participant Name:</td>
        		<td><?php echo $fullname;?></td>
      	</tr>
      	<tr>
        		<td>Email:</td>
        		<td><b><?php echo $email;?><b></td>
      	</tr>
      <tr>
        		<td>password</td>
        		<td><b><?php echo $password;?><b></td>
	    </tr>
</table>
  <footer>
		<div class="footer-container">
			<div class="left-col">
				<p id="end"><i class="fab fa-codiepie"><b>C&lt;&gt;diFY</b></i></p>
				<div class="social-media2">
					<a href="https://www.facebook.com/profile.php?id=100004006897615"><i class="fab fa-facebook-f"></i></a>
					<a href="#"><i class="fab fa-twitter"></i></a>
					<a href="https://www.instagram.com/its_shashwat_3014"><i class="fab fa-instagram"></i></a>
					<a href="mailto:teamcodify03@gmail.com"><i class="fas fa-envelope"></i></a>
					<a href="#"><i class="fab fa-google-plus"></i></a>
					<a href="#"><i class="fab fa-linkedin-in"></i></a>
				</div>
				<p class="rights-text">&copy; 2020 <i class="fab fa-codiepie"><b>C&lt;&gt;diFY</b></i> All Rights
					Reserved.</p>
			</div>
		</div>
	</footer>
  </div>



</body>

</html>