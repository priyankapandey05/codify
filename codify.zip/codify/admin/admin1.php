<?php
	session_start();
	$con=mysqli_connect("localhost","root","","codify")or die(mysqli_error($con));
	$username=mysqli_real_escape_string($con,$_POST['username']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$password=mysqli_real_escape_string($con,$_POST['password']);
	$query="SELECT * from admin WHERE username='$username' and email='$email' and password='$password'";
	$query_result=mysqli_query($con,$query)or die(mysqli_error($con));
	$row=mysqli_fetch_array($query_result);
	if($row['email']==$email && $row['password']==$password){
		header('location:../login.php');
	}
	else{
		header('location:admin.php');
	}
	
	
	

?>