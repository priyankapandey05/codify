<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Codify</title>
  <!--Favicon-->

  <link rel="Favicon" href="https://icons8.com/icon/59997/shopping-cart">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

  <!--CSS Style Sheets-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">

  <!--Font Awesome-->

  <script src="https://kit.fontawesome.com/0873bde953.js" crossorigin="anonymous"></script>
  <script src="js/jquery.js"></script>
  <script src="js/script.js"></script>

  <!--Google Fonts-->


  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@800&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cabin:ital,wght@1,600&display=swap" rel="stylesheet">


  <!--Bootstrap Scripts-->

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
    crossorigin="anonymous"></script>
</head>
<body>

<section id="title">
   
<!-- Nav Bar -->

	<nav class="navbar navbar-expand-sm navbar-dark fixed-top">
        		<a class="navbar-brand" href="../main.html"><i class="fab fa-codiepie"></i> C&lt;&gt;diFY </a>
        		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          	<span class="navbar-toggler-icon"></span>
        		</button>
        		<div class="collapse navbar-collapse navbar-light" id="navbarSupportedContent">
          		<ul class="navbar-nav ml-auto">
            			<li class="nav-item">
					<a class="nav-link" href="../main.html"><b>Home</b></a>
            			</li>
          		</ul>
        		</div>
      	</nav>
    



    <!--main page-->

        <div class="container">
            <div class="forms-container">
                <div class="signin-signup">
                    <form action="admin1.php" method="post" class="sign-up-form" id="FC">
                        <h2 class="title">Admin Login</h2>
			<h4 class="text-warning">Only Admins can access this page</h4>
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="text" required placeholder="Username" name="username">
                        </div>
                        <div class="input-field">
                            <i class="fas fa-envelope"></i>
                            <input type="email" required placeholder="Email" name="email" required>

                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="phone" placeholder="Password" name="password" required>
                        </div>
                        <input type="submit" value="Login" class="btn solid" onClick="valthisform();">
                    </form>
                </div>
            </div>
	    </div>
    </section>

</body>
</html>
