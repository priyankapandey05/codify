


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Codify</title>
	
	
  <!--Favicon-->

  <link rel="Favicon" href="https://icons8.com/icon/59997/shopping-cart">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

  <!--CSS Style Sheets-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="reg2.css">

  <!--Font Awesome-->

  <script src="https://kit.fontawesome.com/0873bde953.js" crossorigin="anonymous"></script>
  <script src="js/jquery.js"></script>
  <script src="js/script.js"></script>

  <!--Google Fonts-->


  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@800&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cabin:ital,wght@1,600&display=swap" rel="stylesheet">


  <!--Bootstrap Scripts-->

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
    crossorigin="anonymous"></script>
</head>
<body>
   
<!-- Nav Bar -->

	<nav class="navbar navbar-expand-sm navbar-dark fixed-top">
        		<a class="navbar-brand" href="../main.php"><i class="fab fa-codiepie"></i> C&lt;&gt;diFY </a>
        		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          	<span class="navbar-toggler-icon"></span>
        		</button>
        		<div class="collapse navbar-collapse navbar-light" id="navbarSupportedContent">
          		<ul class="navbar-nav ml-auto">
            			<li class="nav-item">
					<a class="nav-link" href="../main.php"><b>Home</b></a>
            			</li>
          		</ul>
        		</div>
      	</nav>

    <form action="../success/s.php" method="post" enctype="multipart/form-data">
        <!--Place the address of the success page here !!!-->

        <div class="wrapper">
            <div class="title">
                Registration to C&lt;&gt;diFY
            </div>
            <div class="form">
                <div class="inputfield">
                    <label>Full Name</label>
                    <input type="text" class="input" placeholder="Full name" name="fullname" required>
                </div>
                <div class="inputfield">
                    <label>College</label>
                    <input type="text" class="input" placeholder="Write Full college name" name="college" required>
                </div>
                <div class="inputfield">
                    <label>Branch</label>
                    <div class="custom_select">
                        <select name="branch">
                            <option value="CS">Computer Science</option>
                            <option value="IT">Information Technology</option>
                            <option value="EE">Electrical Engineering</option>
                            <option value="EC">Electronics &amp; Communication</option>
                            <option value="ME">Mechanical Engineering</option>
                            <option value="CE">Civil Engineering</option>
                        </select>
                    </div>
                </div>
                <div class="inputfield">
                    <label>Email Address</label>
                    <input type="email" class="input" placeholder="Email" name="email" required>
                </div>
                <div class="inputfield">
                    <label>Phone Number</label>
                    <input type="tel" class="input" name="phone"  pattern="[0-9]{10}" placeholder="+91 Contact Number" required>
                </div>

                <div class="inputfield check">
                    <label for="c1">Choose Events</label>
                    <div class="checkbox-group" required>
                        <input type="checkbox" name="event[]" id='c1' class="roomselect" value="tickify">Tickify
                        <input type="checkbox" name="event[]" id='c2' class="roomselect" value="coding">Coding maniac
                        <input type="checkbox" name="event[]" id='c3' class="roomselect" value="debug">Debugging
                    </div>
                </div> 
                <div class="inputfield">
                    <label>Team Type</label>
                    <div class="custom_select">
                        <select name="team" readonly>
                            <option value="self">self</option>
                         </select>
                    </div>
                </div>
                <div class="inputfield terms">
                    <label class="check">
                        <input type="checkbox" required>
                        <span class="checkmark"></span>
                    </label>
                    <p>Agreed to terms and conditions</p>
                </div>
                <div class="inputfield">
		      <input type="submit" name="submit" class="btn" value="submit">

		  </div>
            </div>
        </div>
    </form>


</body>

</html>