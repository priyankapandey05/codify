$(document).ready(function(){

jQuery(function ($) {
    //form submit handler
    $('#FC').submit(function (e) {
        //check atleat 1 checkbox is checked
        if (!$('.roomselect').is(':checked')) {
            //prevent the default form submit if it is not checked
            e.preventDefault();
        }
    })
})
 
}); 
