-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 19, 2020 at 03:55 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codify`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'Shreya Agrawal', 'agrawalshreya2515@gmail.com', 'holahola123'),
(2, 'Shashwat Srivastava', 'infinitystudios06@gmail.com', 'holahola456'),
(3, 'Priyanka Pandey', 'priyanka050800@gmail.com', 'holahola789'),
(4, 'Codify', 'teamcodify03@gmail.com', 'codify@123');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) DEFAULT NULL,
  `college` varchar(255) DEFAULT NULL,
  `branch` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `EVENT` varchar(100) DEFAULT NULL,
  `team` varchar(100) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2008 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`ID`, `fullname`, `college`, `branch`, `email`, `phone`, `EVENT`, `team`, `password`) VALUES
(1, 'test', 'test college', 'EC', 'test@gmail.com', '5656565656', 'tickify,', 'self', '97'),
(1999, 'test1', 'test college', 'EC', 'test1@gmail.com', '5656565656', 'tickify,', 'self', '3795'),
(2000, 'testing', 'testing college', 'EC', 'testing@gmail.com', '7070707070', 'tickify,debug,', 'self', '581'),
(2001, 'tes', 'tes college', 'IT', 'tes@gmail.com', '5858585858', 'tickify,debug,', 'self', '978'),
(2002, 'testing1', 'testing1 college', 'CE', 'testing1@gmail.com', '7979797979', 'tickify,', 'self', '6003'),
(2007, 'test77', 'test77 college', 'EE', 'test77@gmail.com', '8989898989', 'tickify,', 'self', '9586'),
(2004, 'hel', 'he', 'CS', 'h@gmail.com', '5656565656', 'tickify,', 'self', '9452'),
(2005, 'tester', 'tester college', 'EE', 'tester@gmail.com', '8989898989', 'tickify,coding,debug,', 'self', '5544'),
(2006, 'test67', 'test67 college', 'ME', 'test67@gmail.com', '7878787878', 'tickify,debug,', 'self', '9240');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
