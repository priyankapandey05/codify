<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Codify</title>
	<!--Favicon-->

	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

	<!--CSS Style Sheets-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
		integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/styles.css">

	<!--Font Awesome-->

	<script src="https://kit.fontawesome.com/0873bde953.js" crossorigin="anonymous"></script>
	<script src="js/jquery.js"></script>
	<script src="js/script.js"></script>

	<!--Google Fonts-->


	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,500&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@800&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,500&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Cabin:ital,wght@1,600&display=swap" rel="stylesheet">


	<!--Bootstrap Scripts-->

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
		integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
		crossorigin="anonymous"></script>


	<style>
		.head {
			background-color: aquamarine;
		}

		#end {
			font-family: 'Catamaran', sans-serif;
			font-weight: bold;
			font-size: 45px;
			text-align: center;
		}
	</style>
</head>

<body>

	<section id="title">

		<!-- Nav Bar -->

		<nav class="navbar navbar-expand-sm navbar-dark fixed-top">
			<a class="navbar-brand" href="main.php"><i class="fab fa-codiepie"></i> C&lt;&gt;diFY </a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
				aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse navbar-light" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<div class="nav-link scollBtn" id="docs" href=""><b>Event</b></div>
					</li>
					<li class="nav-item">
						<div class="nav-link scollBtn" id="spons" href=""><b>Sponsors</b></div>
					</li>
					<li class="nav-item">
						<div class="nav-link scollBtn" id="team-sec-btn" href=""><b>Contact</b></div>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="admin/admin.php"><b>Login</b></a>
					</li>
				</ul>
			</div>
		</nav>

		<!-- Title -->

		<div class="container-fluid2">
			<h1 style="font-weight: bolder; color: coral;"><i class="fab fa-codiepie fa-15x"></i> C&lt;&gt;diFY</h1>
			<h4 style="color: coral;">The Event will Start on 3rd November 2020 !</h4>
			<p id="demo"
				style="text-align: center; margin-top:0px; font-size: 60px; font-weight: bolder; color: coral;"></p>
			<h3 class="reg" style="color: white;">Register Yourself</h3>
			<h2 id="reg3"
				style="font-size: 45px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; color: white;">
				Now!</h2>
			<a href="register/reg2.php"><button type="button" class="btn btn-outline-success" id="reg2">Register
					Now</button></a>
		</div>
	</section>

	<!--Total Registrations-->

	<div class="container-fluid2">
		<h2 class="counter q1">35,345</h2>
		<h3 class="q2">Already Registered !!</h3>
	</div>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.counterup.min.js"></script>
	<script>
		$(document).ready(function () {
			$('.counter').counterUp({
				delay: 10,
				time: 1000
			});
		});
	</script>

	<!--Sections-->


	<!--EVENTS-->

	<div class="container-fluid2" id="event-d">
		<h2 class="q3">Our Events</h2>
		<i class="fas fa-calendar-week"></i>
		<i class="fas fa-calendar-week"></i>
		<i class="fas fa-calendar-week"></i>
		<i class="fas fa-calendar-week"></i>
	</div>

	<section class="events" style="width: auto;">
		<div class="card" data-toggle="modal" data-target="#modal1">
			<div class="card-text">
				<span class="date">Duration : 2 hrs</span>
				<h2>TickiFY</h2>
				<p>Do you think you know everything about coding languages...! Join this event let's check your basics .
					So guys, the next thing you are looking for surely be the Exam pattern &amp; process right? Okay,
					let’s discuss it here.<br><strong style="color: red;">Click To know more !</strong></p>
			</div>
			<div class="card-stats">
				<div class="stat">
					<div class="value">3</div>
					<div class="type">November</div>
				</div>
				<div class="stat">
					<div class="value">MCQ</div>
					<div class="type">Questions</div>
				</div>
				<div class="stat">
					<div class="value">2 </div>
					<div class="type">Hours</div>
				</div>
			</div>
		</div>
		<div class="modal" id="modal1">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header head">
						<center>
							<h2>TickiFY</h2>
						</center>
					</div>
					<div class="modal-body">
						<p style="font-family: cursive;">In this coding event you are provided with list of questions in
							which we have asked about certain languages like C,JAVA,PYTHON..these are common languages
							and we hope that you know well about all three or you have basic knowledge about these
							languages.</p>
						<h6><b>DATE: 4th November 2020</b></h6>
						<h6><b>TIME: 16:00hrs</b></h6><br><br>
						<h5>SOME IMPORTANT POINTS:</h5>
						<ul style="font-family: cursive;">
							<li>
								<p>You are provided with four options-A,B,C,D you have to pick any one answer and tick
									it. you can't tick two answers simultaneously.</p>
							</li>
							<li>
								<p>This event will be of 2:15 hours. Here, 15 minutes is provided for filling the form
									provided for this online test event. And after this you 2 hours test will begin </p>
							</li>
							<li>
								<p>As this event is organised in pandemic so you are not asked to go anywhere you have
									to just take the exam in your home.</p>
							</li>
							<li>
								<p>Your web cam should be in working state because through web cam we will monitor you.
								</p>
							</li>
							<li>
								<p>Questions will be asked from C,PYTHON,JAVA so start preparing for
									the same.</p>
							</li>
							<li>
								<p>These are the beginner level MCQ questions so, it is considered that you know well
									and you will tick the answer on your own without taking any help from any platform.
								</p>
							</li>
							<li>
								<p>We know that you are much capable that you will do this event on your own but in any
									case you take help form any external sources then automatically your online test
									will be finished and your test will be submitted without asking you.</p>
							</li>
							<li>
								<p>Be prepare for this event. All the best!!!</p>
							</li>
						</ul>
					</div>
					<div class="modal-footer head">
						<a href="register/reg2.php"><button type="button" class="btn btn-outline-success btn-res"
								id="reg2" style="align-items: center;">Register Now</button></a>
						<button class="btn btn-danger" data-dismiss="modal">close</button>
					</div>
				</div>
			</div>
		</div>

		<div class="card" data-toggle="modal" data-target="#modal2">
			<div class="card-text">
				<span class="date">Duration : 3 hrs</span>
				<h2>Coding Maniac</h2>
				<p>Are you done..by doing that boring codes daily...! hurry up and participate in this coding
					event. So guys,the next thing you are looking for surely be the Exam pattern &amp; process right?
					Okay, let’s discuss it here.<br><strong style="color: red;">Click To know more !</strong></p>

			</div>
			<div class="card-stats">
				<div class="stat">
					<div class="value">4</div>
					<div class="type">November</div>
				</div>
				<div class="stat">
					<div class="value">Coding</div>
					<div class="type">Questions</div>
				</div>
				<div class="stat">
					<div class="value">3</div>
					<div class="type">Hours</div>
				</div>
			</div>
		</div>
		<div class="modal" id="modal2">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header head">
						<center>
							<h2>Coding Maniac</h2>
						</center>
					</div>
					<div class="modal-body">
						<p style="font-family: cursive;">In this coding event you are given set of questions which
							contains 5 coding questions which you have to solve. These questions will be of 20 marks
							each. And according to your performance you will be evaluated.</p>
						<h6><b>DATE: 3rd November 2020</b></h6>
						<h6><b>TIME: 16:00hrs</b></h6><br><br>
						<h5>SOME IMPORTANT POINTS:</h5>
						<ul style="font-family: cursive;">
							<li>
								<p>There are 5 questions of 20 marks.</p>
							</li>
							<li>
								<p>This event will be of 3.15 hours.in 15 minutes you have to complete the form filling
									procedures. And then start your coding. </p>
							</li>
							<li>
								<p>As this event is organised in pandemic so you are not asked to go anywhere you have
									to just take the exam in your home.</p>
							</li>
							<li>
								<p>Your web cam should be in working state because through web cam we will monitor you.
								</p>
							</li>
							<li>
								<p>Questions will be asked from C,PYTHON,JAVA so start preparing for the same.</p>
							</li>
							<li>
								<p>These are the beginner level coding questions so, it is considered that you know well
									and you will code by your own.</p>
							</li>
							<li>
								<p>We know that you are much capable that you will do this event on your own but in any
									case you take help form any external sources then automatically your online test
									will be finished and your test will be submitted wothout asking you.</p>
							</li>
							<li>
								<p>Be prepare for this event. All the best!!</p>
							</li>
						</ul>
					</div>
					<div class="modal-footer head">
						<a href="register/reg2.php"><button type="button" class="btn btn-outline-success btn-res"
								id="reg2" style="align-items: center;">Register Now</button></a>
						<button class="btn btn-danger" data-dismiss="modal">close</button>
					</div>
				</div>
			</div>
		</div>

		<div class="card" data-toggle="modal" data-target="#modal3">
			<div class="card-text">
				<span class="date">Duration : 2 hrs</span>
				<h2>Debugging</h2>
				<p>Are you fed up of finding that same error daily ! Let's explore more errors by debugging them. So
					guys,the next thing you are looking for surely be the Exam pattern &amp; process right? Okay, let’s
					discuss it here.<br><strong style="color: red;">Click To know more !</strong></p>
			</div>
			<div class="card-stats">
				<div class="stat">
					<div class="value">5</div>
					<div class="type">November</div>
				</div>
				<div class="stat">
					<div class="value">Debugging</div>
					<div class="type">Questions</div>
				</div>
				<div class="stat">
					<div class="value">2 </div>
					<div class="type">Hours</div>
				</div>
			</div>
		</div>
		<div class="modal" id="modal3">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header head">
						<center>
							<h2>Debugging</h2>
						</center>
					</div>
					<div class="modal-body">
						<p style="font-family: cursive;">In this coding event you are provided with 5 questions in which
							you to resolve the code and find the error and remove the error. This event is not for the
							beginner level but for the advanced coders. You must know about different error and know how
							to solve it.</p>
						<h6><b>DATE: 5th November 2020</b></h6>
						<h6><b>TIME: 16:00hrs</b></h6><br><br>
						<h5>SOME IMPORTANT POINTS:</h5>
						<ul style="font-family: cursive;">
							<li>
								<p>You have 5 questions and multiple errors in it.</p>
							</li>
							<li>
								<p>You have to solve all those error and submit the code on time.</p>
							</li>
							<li>
								<p>This website has its own IDE so you don't have to worry about how will you manage to
									code.</p>
							</li>
							<li>
								<p>this event will be of 2:15 hours. Here, 15 minutes is provided for filling the form
									and rest for finding the error and debbuing them. </p>
							</li>
							<li>
								<p>As this event is organised in pandemic so you are not asked to go anywhere you have
									to just take the exam in your home</p>
							</li>
							<li>
								<p>Your web cam should be in working state because through web cam we will monitor you.
								</p>
							</li>
							<li>
								<p>Questions will be asked from C,PYTHON,JAVA so start preparing for the same.</p>
							</li>
							<li>
								<p>These are the advanced level debugging questions so, it is considered that you know
									well and you will debug it on your own without taking any help from any platform.
								</p>
							</li>
							<li>
								<p>We know that you are much capable that you will do this event on your own but in any
									case you take help form any external sources then automatically your online test
									will be finished and your test will be submitted wothout asking you.</p>
							</li>
							<li>
								<p>Be prepare for this event. All the best!!</p>
							</li>
						</ul>
					</div>
					<div class="modal-footer head">
						<a href="register/reg2.php"><button type="button" class="btn btn-outline-success btn-res"
								id="reg2" style="align-items: center;">Register Now</button></a>
						<button class="btn btn-danger" data-dismiss="modal">close</button>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Testimonials -->

	<div class="container">
		<div class="container-fluid2" id="spons2" style="height: 250px;">
			<h2 class="q4">Our Sponsors</h2>
			<i class="fas fa-star"></i>
			<i class="fas fa-star"></i>
			<i class="fas fa-star"></i>
			<i class="fas fa-star"></i>
		</div>
		<div class="container">
			<div class="box">
				<div class="icon">01</div>
				<div class="content">
					<h3>Rahul Sharma(Tech)</h3>
					<p>Codify helps me to enhance my skill in coding</p>
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="icon">02</div>
				<div class="content">
					<h3>Ishan Verma(BYJU's)</h3>
					<p>Codify ! The best platform to Test your Powers </p>
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="icon">03</div>
				<div class="content">
					<h3>Suchita Singh(TNW)</h3>
					<p>Codify - Give Chance to test Yourself</p>
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
				</div>
			</div>
		</div>
	</div>



	<!-- Sponsors -->

	<section class="colored-section" id="press">
		<div class="container-fluid2">
			<img class="press-logo " src="images/TechCrunch.png" alt="tc-logo">
			<img class="press-logo2" src="images/byju.png" alt="tnw-logo">
			<img class="press-logo" src="images/tnw.png" alt="mashable-logo" style="width: 220px;">
		</div>
	</section>



	<!--Team Members-->

	<div class="contain" id="team-section">
		<h2 class="heading">MEET THE TEAM</h2>
		<div class="card-wrapper">
			<div class="card" id="pp">
				<img src="images/pic2.jpg" alt="priyanka" class="card-img">
				<img src="images/sh.png" alt="shreya" class="profile-img">
				<h1>SHASHWAT SRIVASTAVA</h1>
				<p class="job-title">FRONT-END DEVELOPER<br>html,css,javascript</p>
				<ul class="social-media">
					<li><a href=""><i class="fab fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/home"><i class="fab fa-twitter"></i></a></li>
					<li><a href="https://www.instagram.com/its_shashwat_3014"><i class="fab fa-instagram"></i></a></li>
					<li><a href="https://www.linkedin.com/in/shashwat-srivastava-6b8191137/"><i
								class="fab fa-linkedin"></i></a></li>
				</ul>
			</div>
			<div class="card" id="pp">
				<img src="images/pic2.jpg" alt="priyanka" class="card-img">
				<img src="images/pp.jpg" alt="shreya" class="profile-img">
				<h1>PRIYANKA PANDEY</h1>
				<p class="job-title">BACK-END DEVELOPER<br>PHP,MySQL</p>
				<ul class="social-media">
					<li><a href="https://www.facebook.com/profile.php?id=100004006897615"><i class="fab fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/home"><i class="fab fa-twitter"></i></a></li>
					<li><a href="https://www.instagram.com/pandey0508/"><i class="fab fa-instagram"></i></a></li>
					<li><a href="https://www.linkedin.com/in/priyanka-pandey-a38a7b1ab"><i class="fab fa-linkedin"></i></a></li>
				</ul>
			</div>
			<div class="card" id="pp">
				<img src="images/pic2.jpg" alt="priyanka" class="card-img">
				<img src="images/sa.png" alt="shreya" class="profile-img">
				<h1>SHREYA AGRAWAL</h1>
				<p class="job-title">FRONT-END DEVELOPER<br>html,CSS,bootstrap,javascript</p>
				<ul class="social-media">
					<li><a href="#"><i class="fab fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/home"><i class="fab fa-twitter"></i></a></li>
					<li><a href="https://www.instagram.com/agrawalshreya2515/"><i class="fab fa-instagram"></i></a></li>
					<li><a href="https://www.linkedin.com/in/shreya-agrawal-8b73031b3/"><i
								class="fab fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>






	<!--Prizes-->

	<div class="container ">
		<div class="section-header" style="padding-bottom: 10%; padding-left: 40%;">
			<h2 class="q4">PRIZES</h2>
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-6 col">
				<div class="thumbnail text-center">
					<img src="images/miband.png" alt="responsive image" class="imagess">
					<div class="caption">
						<h3 style="font-family: fantasy;">3rd PRIZE</h3>
						<p>Mi band<br>Worth ₹1500/-</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col">
				<div class="thumbnail text-center" alt="responsive image" class="imagess">
					<img src="images/lap2.jpg" class="laptop">
					<div class="caption">
						<h3 style="font-family: fantasy;">1st PRIZE</h3>
						<p>HP laptop<br>Worth ₹50,000/-</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col">
				<div class="thumbnail text-center">
					<img src="images/tablet.jpg" alt="responsive image" class="imagess">
					<div class="caption">
						<h3 style="font-family: fantasy;">2nd PRIZE</h3>
						<p>Microsoft tablet<br>Worth ₹10,000/-</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!--Footer-->

	<footer>
		<div class="footer-container">
			<div class="left-col">
				<p id="end"><i class="fab fa-codiepie"><b>C&lt;&gt;diFY</b></i></p>
				<div class="social-media2">
					<a href="https://www.facebook.com/profile.php?id=100004006897615"><i class="fab fa-facebook-f"></i></a>
					<a href="#"><i class="fab fa-twitter"></i></a>
					<a href="https://www.instagram.com/its_shashwat_3014"><i class="fab fa-instagram"></i></a>
					<a href="mailto:teamcodify03@gmail.com"><i class="fas fa-envelope"></i></a>
					<a href="#"><i class="fab fa-google-plus"></i></a>
					<a href="#"><i class="fab fa-linkedin-in"></i></a>
				</div>
				<p class="rights-text">&copy; 2020 <i class="fab fa-codiepie"><b>C&lt;&gt;diFY</b></i> All Rights
					Reserved.</p>
			</div>
		</div>
	</footer>

</body>

</html>